# 샘플 데이터 
아래 URI 접속 시 샘플 데이터 생성 됨
POST http://localhost:9000/man/schd
