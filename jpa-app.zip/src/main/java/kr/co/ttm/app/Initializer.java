package kr.co.ttm.app;

import java.util.List;

import org.springframework.session.web.context.AbstractHttpSessionApplicationInitializer;

import kr.co.ttm.app.config.container.HttpSessionConfig;

public class Initializer extends AbstractHttpSessionApplicationInitializer {
	public Initializer() {
        super(HttpSessionConfig.class);
	}
}
