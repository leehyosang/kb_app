package kr.co.ttm.app;

import java.util.TimeZone;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.scheduling.annotation.EnableScheduling;

import kr.co.ttm.app.controller.SampleController;
import kr.co.ttm.app.core.scheduler.TTMSchedulerController;
import lombok.AllArgsConstructor;

@SpringBootApplication
@EnableJpaAuditing
@EnableScheduling
@AllArgsConstructor
public class SchedulerApplication {
	
	private TTMSchedulerController schdCont;
	
	@PostConstruct
	public void started() {
		TimeZone.setDefault(TimeZone.getTimeZone("Asia/Seoul"));
		
		// 스케쥴러 정보 인스턴스화
		this.schdCont.initScheduleMap();
		
		// 스케쥴러 컨트롤러 실행
		this.schdCont.startAllSchedulers();
		
	}
	
	@PreDestroy
	public void closed() {
		
		// 어플리케이션 종료 시 모든 스케쥴러 쓰레드 종료
		this.schdCont.stopAllSchedulers();
	}

	public static void main(String[] args) {
		
		SpringApplication.run(SchedulerApplication.class, args);
	}

}
