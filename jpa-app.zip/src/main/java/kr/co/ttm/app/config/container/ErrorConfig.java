package kr.co.ttm.app.config.container;

import org.springframework.context.annotation.Configuration;

@Configuration
public class ErrorConfig {
	/*
	@Bean
	  public EmbeddedServletContainerCustomizer containerCustomizer() {
	    return new EmbeddedServletContainerCustomizer() {	 
	      @Override
	      public void customize(ConfigurableEmbeddedServletContainer container) {
	        ErrorPage error403Page = new ErrorPage(HttpStatus.FORBIDDEN, "/static/error/403.html");
	        ErrorPage error404Page = new ErrorPage(HttpStatus.NOT_FOUND, "/static/error/404.html");
	        ErrorPage error500Page = new ErrorPage(HttpStatus.INTERNAL_SERVER_ERROR, "/static/error/500.html");
	        
	        JspServlet jspServlet = new JspServlet();
	        HashMap<String, String> initParams = new HashMap<>();
            initParams.put("mappedfile", "false");
            jspServlet.setInitParameters(initParams);
            container.setJspServlet(jspServlet);
	 
	        container.addErrorPages(error403Page, error404Page, error500Page);
	      }
	    };
	  }
	*/
}
