package kr.co.ttm.app.config.db;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.connection.RedisPassword;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.session.data.redis.config.annotation.web.http.EnableRedisHttpSession;

import com.fasterxml.jackson.databind.ObjectMapper;

@Configuration
@EnableRedisHttpSession
public class RedisConfig {
		
	@Autowired
    private Environment env;
	
	/*
	@Bean
	public ObjectMapper objectMapper(){
		return Jackson2ObjectMapperBuilder.json()
				.serializationInclusion(JsonInclude.Include.NON_NULL)
				.featuresToDisable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
				.build();
	}
	*/

	@Bean("commonConnectionFactory")
	@Primary
	public JedisConnectionFactory commonConnectionFactory() {
		RedisStandaloneConfiguration redisConfig = new RedisStandaloneConfiguration();
		redisConfig.setHostName(env.getProperty("spring.redis.host"));
		redisConfig.setPort(Integer.parseInt(env.getProperty("spring.redis.port")));
		redisConfig.setDatabase(0);
		redisConfig.setPassword(RedisPassword.of(env.getProperty("spring.redis.password")));
		
		return new JedisConnectionFactory(redisConfig);
	}
	
	@Bean("commonRedisTemplate")
	@Primary
	public RedisTemplate<String, Object> commonRedisTemplate() {
		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
		redisTemplate.setKeySerializer(new StringRedisSerializer());
		redisTemplate.setValueSerializer(new StringRedisSerializer());
		redisTemplate.setConnectionFactory(commonConnectionFactory());		
		return redisTemplate;
	}
	
	@Bean("cacheConnectionFactory")
	public JedisConnectionFactory cacheConnectionFactory() {				
		RedisStandaloneConfiguration redisConfig = new RedisStandaloneConfiguration();
		redisConfig.setHostName(env.getProperty("spring.redis.host"));
		redisConfig.setPort(Integer.parseInt(env.getProperty("spring.redis.port")));
		redisConfig.setDatabase(Integer.parseInt(env.getProperty("spring.redis.cache")));
		redisConfig.setPassword(RedisPassword.of(env.getProperty("spring.redis.password")));
		
		return new JedisConnectionFactory(redisConfig);
	}
	
	@Bean("cacheRedisTemplate")
	public RedisTemplate<Object, Object> cacheRedisTemplate(ObjectMapper objectMapper) {
		RedisTemplate<Object, Object> redisTemplate = new RedisTemplate<>();
		
		
		redisTemplate.setKeySerializer(new StringRedisSerializer());
		redisTemplate.setValueSerializer(new GenericJackson2JsonRedisSerializer());
		redisTemplate.setHashKeySerializer(new StringRedisSerializer());
		redisTemplate.setHashValueSerializer(new GenericJackson2JsonRedisSerializer());
			    
		redisTemplate.setConnectionFactory(cacheConnectionFactory());
		return redisTemplate;
	}
}
