package kr.co.ttm.app.controller;

import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import kr.co.ttm.app.core.TTMControllerCore;
import kr.co.ttm.app.core.scheduler.TTMSchedulerController;
import kr.co.ttm.app.psdomain.scheduler.SchedulerInfo;
import lombok.AllArgsConstructor;

@RestController
@RequestMapping("/man")
@AllArgsConstructor
public class ManageController extends TTMControllerCore {
	
	private TTMSchedulerController schdCont;

	@PostMapping("/schd")
	public void registSchedule() {
		SchedulerInfo info =  SchedulerInfo.builder()
								.schdGrp("TEST")
								.schdNm("SCHD1")
								.cronExp("0/5 * * * * *")
								.title("테스트 스케쥴")
								.comment("테스트 스케쥴러 입니다.")
								.useYn(true)
								.build();
		
		if(this.schdCont.registSchedulerInfo(info) != null) {
			logger.info(info.getSchdNm() + " is registed.");
		}
	}
	
	@PutMapping("/schd/{no}")
	public void updateSchedule(@PathVariable long no) {		
		SchedulerInfo info = this.schdCont.updateSchedulerUseYn(no, false);
		
		if(info != null) {
			logger.info(info.getSchdNm() + " is stoped.");
		}
								
	}
	
	@PatchMapping("/schd/{no}")
	public void setScheduleUsed(@PathVariable long no, 
			@RequestParam(name = "used", required = true) boolean used) {
		
		// 상태 변경
		SchedulerInfo info = this.schdCont.updateSchedulerUseYn(no, used);
				
		// 상태에 따라 스케쥴러 제어
		if(!used) {
			info.getSchduler().stopScheduler();
		}else {
			info.getSchduler().startScheduler();
		}		
	}
	
	
	
}
