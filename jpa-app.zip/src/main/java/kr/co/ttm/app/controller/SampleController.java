package kr.co.ttm.app.controller;

import org.springframework.web.bind.annotation.RestController;

import kr.co.ttm.app.core.TTMControllerCore;
import kr.co.ttm.app.core.scheduler.TTMSchdulerControllerCore;
import kr.co.ttm.app.core.scheduler.TTMSchedulerController;
import kr.co.ttm.app.scheduler.SampleScheduler;
import lombok.AllArgsConstructor;

@AllArgsConstructor
@RestController("SampleController")
public class SampleController extends TTMControllerCore implements TTMSchdulerControllerCore{
	
	private TTMSchedulerController schdCont;
	
	private SampleScheduler sampleSchd;
		
	@Override
	public void startSchedulers() {		
		// 스케쥴러 인스턴스 저장
		this.schdCont.setSchdulerInstance(this.sampleSchd);
		
		// 스케쥴러의 사용여부를 체크하여 실행
		if(this.schdCont.getSchedulerInfo(this.sampleSchd).isUseYn()){
			sampleSchd.startScheduler();
		}
	}


	@Override
	public void stopSchedulers() {
		sampleSchd.destroy();
		
	}
	
	
	

}
