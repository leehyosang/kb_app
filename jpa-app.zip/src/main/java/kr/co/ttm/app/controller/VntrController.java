package kr.co.ttm.app.controller;

import org.springframework.web.bind.annotation.RestController;

import kr.co.ttm.app.core.TTMControllerCore;
import kr.co.ttm.app.core.scheduler.TTMSchdulerControllerCore;
import kr.co.ttm.app.core.scheduler.TTMSchedulerController;
import kr.co.ttm.app.scheduler.VntrScheduler;
import kr.co.ttm.app.service.KiprisFileService;
import kr.co.ttm.app.service.VntrService;
import lombok.AllArgsConstructor;

@AllArgsConstructor
@RestController("VntrController")
public class VntrController extends TTMControllerCore implements TTMSchdulerControllerCore{
	
	private TTMSchedulerController schdCont;
	
	private VntrScheduler vntrSchd;
	
	@Override
	public void startSchedulers() {		
		// 스케쥴러 인스턴스 저장
		this.schdCont.setSchdulerInstance(this.vntrSchd);
		
		System.out.println("use_yn ===>"+this.schdCont.getSchedulerInfo(this.vntrSchd).isUseYn());
		// 스케쥴러의 사용여부를 체크하여 실행
		if(this.schdCont.getSchedulerInfo(this.vntrSchd).isUseYn()){
			vntrSchd.startScheduler();
		}
		
		
	}

	@Override
	public void stopSchedulers() {
		vntrSchd.destroy();
	}
	
}
