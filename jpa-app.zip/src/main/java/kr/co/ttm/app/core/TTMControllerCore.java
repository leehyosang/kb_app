package kr.co.ttm.app.core;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class TTMControllerCore {	
	protected final Logger logger = LoggerFactory.getLogger(this.getClass());
			
	
	protected String getSessionId(HttpServletRequest request) {
		HttpSession session = request.getSession();
		
		return session.getId();		
	}
		
}
