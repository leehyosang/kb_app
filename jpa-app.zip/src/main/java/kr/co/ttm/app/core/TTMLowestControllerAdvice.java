package kr.co.ttm.app.core;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

@ControllerAdvice
@Order(Ordered.LOWEST_PRECEDENCE)
public class TTMLowestControllerAdvice {
	private final Logger logger = LoggerFactory.getLogger(TTMLowestControllerAdvice.class);
	
	@ExceptionHandler(Exception.class)
    public String handleAnyException(HttpServletRequest request, HttpServletResponse response, Exception e) {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PrintStream printStream = new PrintStream(out);
		e.printStackTrace(printStream);
		
		logger.error(out.toString());
		
		request.setAttribute("message", "internal server error");
		request.setAttribute("data", e.toString());
		
		return "forward:/err/handle";
    }

}
