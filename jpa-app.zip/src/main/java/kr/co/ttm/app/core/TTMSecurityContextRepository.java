package kr.co.ttm.app.core;

import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.stereotype.Component;

@Component
public class TTMSecurityContextRepository extends HttpSessionSecurityContextRepository {
	public TTMSecurityContextRepository() {
		super();
	}
}
