package kr.co.ttm.app.core;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class TTMServiceCore {
	protected final Logger logger = LoggerFactory.getLogger(this.getClass());

}
