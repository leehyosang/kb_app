package kr.co.ttm.app.core.scheduler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.Trigger;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.stereotype.Component;

import lombok.Data;

public abstract class TTMDynamicScheduler {
	protected Logger logger = LoggerFactory.getLogger(this.getClass());
	
	private ThreadPoolTaskScheduler scheduler;
	private String schdGrp;
	private String schdNm;	
	
	public String getSchdGrp() {
		return schdGrp;
	}

	public void setSchdGrp(String schdGrp) {
		this.schdGrp = schdGrp;
	}

	public String getSchdNm() {
		return schdNm;
	}

	public void setSchdNm(String schdNm) {
		this.schdNm = schdNm;
	}
	
	public void destroy() {
		this.scheduler.destroy();
	}

	public void stopScheduler() {
        scheduler.shutdown();
    }
 
    public void startScheduler() {
        scheduler = new ThreadPoolTaskScheduler();
        scheduler.initialize();
        scheduler.schedule(this.getRunnable(), this.getTrigger());        
    }
 
    private Runnable getRunnable(){
        return new Runnable(){
            @Override
            public void run() {
                runner();
            }
        };
    }
    
    public abstract void runner();
 
    public abstract Trigger getTrigger();

}
