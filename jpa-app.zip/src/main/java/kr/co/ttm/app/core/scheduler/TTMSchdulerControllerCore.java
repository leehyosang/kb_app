package kr.co.ttm.app.core.scheduler;

public interface TTMSchdulerControllerCore {
	/**
	 * 컨트롤러 내 모든 스케쥴러 스타트 
	 */
	public void startSchedulers();
	
	/**
	 * 컨트롤러 내 모든 스케쥴러 종료
	 */
	public void stopSchedulers();
}
