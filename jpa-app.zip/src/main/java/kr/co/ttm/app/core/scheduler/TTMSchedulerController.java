package kr.co.ttm.app.core.scheduler;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import kr.co.ttm.app.psdomain.scheduler.SchedulerInfo;
import kr.co.ttm.app.psdomain.scheduler.SchedulerInfoRepository;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
public class TTMSchedulerController {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@NonNull
	private SchedulerInfoRepository schdRepo;
	
	@NonNull
	private ApplicationContext context;
	
	@Value("${scheduler.controller.list}")
	private List<String> list;
	
	private Map<String, SchedulerInfo> schdMap;
	
	
	/**
	 * 스케쥴러 정보 초기화
	 */
	public void initScheduleMap() {
		schdMap = new HashMap<String, SchedulerInfo>();		
		
		schdRepo.findAll().forEach( item -> {
			String key = item.getSchdGrp() + "_" + item.getSchdNm();
			
			this.schdMap.put(key, item);			
		});
		
	}
	
	
	/**
	 * yml 파일에 등록된 스케쥴러 컨트롤러 실행 
	 */
	public void startAllSchedulers() {
		System.out.println("list>>>>"+list.toString());
		// Bean name으로 객체를 찾아 실행
		for(String beanNm : list) {
			(
					(TTMSchdulerControllerCore) context.getBean(beanNm)
			).startSchedulers();
		}
		
	}
	
	public void stopAllSchedulers() {
		
		// Bean name으로 객체를 찾아 실행
		for(String beanNm : list) {
			(
					(TTMSchdulerControllerCore) context.getBean(beanNm)
			).stopSchedulers();
		}
		
	}
	
	/**
	 * 스케쥴러 키 생성
	 * @param schdGrp
	 * @param schdNm
	 * @return String
	 */
	private String getKey(String schdGrp, String schdNm) {
		return schdGrp + "_" + schdNm;
	}
	
	
	
	/**
	 * 스케쥴러 정보 조회
	 * @param schdGrp
	 * @param schdNm
	 * @return
	 */
	public SchedulerInfo getSchedulerInfo(String schdGrp, String schdNm) {
		return this.schdMap.get(this.getKey(schdGrp, schdNm));
	}	
	
	public SchedulerInfo getSchedulerInfo(TTMDynamicScheduler dySchd) {
		return this.getSchedulerInfo(dySchd.getSchdGrp(), dySchd.getSchdNm());
	}
		
	public SchedulerInfo updateLastRuntime(String schdGrp, String schdNm) {
		SchedulerInfo info = this.schdMap.get(this.getKey(schdGrp, schdNm));
		
		// 실행시간 업데이트
		info.setLastRunTm(LocalDateTime.now());		
		schdRepo.save(info);
		
		return info;
	}
	
	
	public SchedulerInfo registSchedulerInfo(SchedulerInfo info) {
		info = schdRepo.save(info);
		
		// DB 저장 후 인스턴스에 추가
		if(info != null) {
			this.schdMap.put(
					this.getKey(info.getSchdGrp(), info.getSchdNm())
					, info);
		}
		
		return info;
	}
	
	public SchedulerInfo updateSchedulerUseYn(long no, boolean useYn) {
		SchedulerInfo info = schdRepo.findById(no).get();
		
		info.setUseYn(useYn);
		
		info = schdRepo.save(info);
		
		// DB 저장 후 인스턴스 객체에서 교체
		if(info != null) {
			// 기존 인스턴스 정보 저장			
			info.setSchduler(
						this.schdMap.get(this.getKey(info.getSchdGrp(), info.getSchdNm())).getSchduler()
					);
			
			this.schdMap.put(
					this.getKey(info.getSchdGrp(), info.getSchdNm())
					, info);
		}
		
		return info;
		
	}
	
	public void setSchdulerInstance(TTMDynamicScheduler instance) {
		this.schdMap
		.get(this.getKey(instance.getSchdGrp(), instance.getSchdNm()))
		.setSchduler(instance);
	}
	

}
