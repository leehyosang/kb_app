package kr.co.ttm.app.mydomain.vntr;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface VntrInfoRepository extends JpaRepository<VntrInfo, Integer> {
	@Query(value = "select "
			+ " RnDRegisterApprovalNumber AS rnDRegisterApprovalNumber, "
			+ " CompanyName AS companyName, "
			+ " CompanyRegistrationNumber AS companyRegistrationNumber, "
			+ " CAST(TotalAssets AS INTEGER) AS totalAssets, "
			+ " CAST(CapitalStock AS INTEGER) AS capitalStock, "
			+ " CAST(SalesAll AS INTEGER) AS salesAll, "
			+ " CAST(SalesBusinessCategory AS INTEGER) AS salesBusinessCategory, "
			+ " RegistrationField AS registrationField, "
			+ " CompanyType AS companyType, "
			+ " MajorActivity1 AS majorActivity1, "
			+ " MajorActivity2 AS majorActivity2, "
			+ " MajorActivity3 AS majorActivity3, "
			+ " CAST(EmployeeCount AS INTEGER) AS employeeCount, "
			+ " CAST(EngineerCount AS INTEGER) AS engineerCount, "
			+ " CAST(FacilityCount AS INTEGER) AS facilityCount, "
			+ " ResearchSpaceType AS researchSpaceType, "
			+ " CAST(ResearchInvestmentResearchCost AS INTEGER) AS researchInvestmentResearchCost, "
			+ " CAST(ResearchInvestmentFacilityCost AS INTEGER) AS researchInvestmentFacilityCost "
			+ " FROM TB_AFFL_BASIC "
			+ "where 1=1 "
			+ "order by CompanyRegistrationNumber asc", nativeQuery = true)
	public List<VntrInfo> getVntrList();
}
