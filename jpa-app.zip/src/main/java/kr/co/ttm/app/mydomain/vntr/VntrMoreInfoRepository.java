package kr.co.ttm.app.mydomain.vntr;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface VntrMoreInfoRepository extends JpaRepository<VntrMoreInfo, Integer> {
	@Query(value = "select "
			+ " RnDRegisterApprovalNumber AS rnDRegisterApprovalNumber, "
			+ " CompanyName AS companyName, "
			+ " CompanyRegistrationNumber AS companyRegistrationNumber, "
			+ " FacilityGoodsName AS facilityGoodsName, "
			+ " FacilityModelName AS facilityModelName, "
			+ " CAST(FacilityUnitcost AS INTEGER) AS facilityUnitcost, "
			+ " CAST(FacilityQuantity AS INTEGER) AS facilityQuantity, "
			+ " FacilityProductionCompany AS facilityProductionCompany, "
			+ " FacilityInstallationPlace AS facilityInstallationPlace, "
			+ " FacilityIntroductionDate AS facilityIntroductionDate, "
			+ " FacilityUseCode AS facilityUseCode "
			+ " from TB_AFFL_MORE "
			+ " where 1=1 "
			+ "order by CompanyRegistrationNumber asc", nativeQuery = true)
	public List<VntrMoreInfo> getVntrMoreList();
}
