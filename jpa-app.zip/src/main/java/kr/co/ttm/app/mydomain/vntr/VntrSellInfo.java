package kr.co.ttm.app.mydomain.vntr;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Entity
@Table(name="vntr_sell_info")
@EntityListeners(value = { AuditingEntityListener.class })
public class VntrSellInfo {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="CompanyRegistrationNumber", length = 12)
	private String companyRegistrationNumber;
	
	@Column(name="RnDRegisterApprovalNumber", length = 10)
	private String rnDRegisterApprovalNumber;

	@Column(name="CompanyName", length = 100)
	private String companyName;

	@Column(name="ChargeName", length = 30)
	private String chargeName;
	
	@Column(name="ChargePosition", length = 20)
	private String chargePosition;
	
	@Column(name="ChargePhoneNumber", length = 13)
	private String chargePhoneNumber;
	
	@Column(name="Homepage", length = 100)
	private String homepage;

	@Column(name="BusinessCategoryClassification", length = 14)
	private String businessCategoryClassification;

	@Column(name="FoundationDate", length = 10)
	private String foundationDate;

	@Column(name="CEOName", length = 30)
	private String cEOName;

	@Column(name="Address", length = 201)
	private String address;
	
	@Column(name="TelNumber", length = 14)
	private String telNumber;
	
	@Column(name="FaxNumber", length = 15)
	private String faxNumber;
	
	/*
	@Column(name="BusinessRegistrationFile", length = 30)
	private byte[] businessRegistrationFile;
	*/
}