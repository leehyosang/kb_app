package kr.co.ttm.app.mydomain.vntr;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface VntrSellInfoRepository extends JpaRepository<VntrSellInfo, Integer> {
	@Query(value = "select "
			 + " RnDRegisterApprovalNumber AS rnDRegisterApprovalNumber, "
			 + " CompanyName AS companyName, "
			 + " CompanyRegistrationNumber AS companyRegistrationNumber, "
			 + " ChargeName AS chargeName, "
			 + " ChargePosition AS chargePosition, "
			 + " ChargePhoneNumber AS chargePhoneNumber, "
			 + " Homepage AS homepage, "
			 + " BusinessCategoryClassification AS businessCategoryClassification, "
			 + " FoundationDate AS foundationDate, "
			 + " CEOName AS cEOName, "
			 + " Address AS address, "
			 + " TelNumber AS telNumber, "
			 + " FaxNumber AS faxNumber "
			 //+ "  ,BusinessRegistrationFile AS BusinessRegistrationFile "
			 + " from TB_AFFL_SELL "
			+ "order by CompanyRegistrationNumber asc", nativeQuery = true)
	public List<VntrSellInfo> getVntrSellList();
}
