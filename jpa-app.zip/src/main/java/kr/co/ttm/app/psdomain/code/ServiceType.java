package kr.co.ttm.app.psdomain.code;

import java.util.Arrays;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ServiceType {

	NAVER("N");

	private String dbType;
	
	public static ServiceType ofDbType(String dbType) throws Exception {
		return Arrays.stream(ServiceType.values())
			.filter( v -> v.getDbType().equals(dbType))
			.findAny()
			.orElseThrow(() -> new Exception("서비스 타입" + dbType + "이 존재하지 않습니다."));
	}
}
