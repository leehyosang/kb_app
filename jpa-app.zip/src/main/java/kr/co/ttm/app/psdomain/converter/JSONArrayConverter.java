package  kr.co.ttm.app.psdomain.converter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Converter
public class JSONArrayConverter implements AttributeConverter<JSONArray, String> {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Override
	public String convertToDatabaseColumn(JSONArray attribute) {
		String result = null;
		try {
			if(attribute != null) {
				result = attribute.toJSONString();
			}			
			//logger.info(result);
		} catch(Exception e) {
			logger.error(e.getMessage());
		}
		
		
		return result;
	}

	@Override
	public JSONArray convertToEntityAttribute(String dbData) {
		JSONArray result = null;
		try {
			if(dbData != null) {
				result = (JSONArray) (new JSONParser()).parse(dbData);
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		
		
		return result;
	}

}
