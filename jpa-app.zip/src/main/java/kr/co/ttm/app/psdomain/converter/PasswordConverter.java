package  kr.co.ttm.app.psdomain.converter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Converter
public class PasswordConverter implements AttributeConverter<String, String> {

	@Override
	public String convertToDatabaseColumn(String attribute) {
		String result = "";
		try {
			// TODO 수정필요
			//String origin = AES.decryptBase64(attribute);
			String origin = attribute;
			//byte[] utf8 = origin.getBytes("UTF-8");
			//result = "*" + DigestUtils.sha1Hex(DigestUtils.sha1(utf8)).toUpperCase();

			result = new BCryptPasswordEncoder().encode(origin);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
        return result;
	}

	@Override
	public String convertToEntityAttribute(String dbData) {
		return dbData;
	}

}
