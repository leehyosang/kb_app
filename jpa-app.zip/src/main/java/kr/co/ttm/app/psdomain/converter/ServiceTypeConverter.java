package  kr.co.ttm.app.psdomain.converter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import kr.co.ttm.app.psdomain.code.ServiceType;


@Converter
public class ServiceTypeConverter implements AttributeConverter<ServiceType, String> {

	@Override
	public String convertToDatabaseColumn(ServiceType attribute) {
		return attribute.getDbType();
	}

	@Override
	public ServiceType convertToEntityAttribute(String dbData) {
		ServiceType result = null;
		
		try {
			result = ServiceType.ofDbType(dbData);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

}
