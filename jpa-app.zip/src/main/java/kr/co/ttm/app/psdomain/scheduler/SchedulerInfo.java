package kr.co.ttm.app.psdomain.scheduler;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import kr.co.ttm.app.core.scheduler.TTMDynamicScheduler;
import kr.co.ttm.app.psdomain.converter.BooleanToYnConverter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Entity
@Table(name="scheduler_info", uniqueConstraints={
		   @UniqueConstraint(columnNames={"SCHD_GRP", "SCHD_NM"})
		})
@EntityListeners(value = { AuditingEntityListener.class })
public class SchedulerInfo {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "NO")
	private long id;
	
	@Column(name = "SCHD_GRP", length = 50)
	private String schdGrp;
	
	@Column(name = "SCHD_NM", length = 50)
	private String schdNm;
	
	@Column(name = "CRON_EXP", length = 50)
	private String cronExp;
	
	@Column(name = "TITLE", length = 100)
	private String title;
	
	@Column(name = "COMMENT")
	private String comment;
	
    @Column(name = "LAST_RUN_TM")
    private LocalDateTime lastRunTm;
    
    @Transient
    private TTMDynamicScheduler schduler;
    
    @Column(name = "USE_YN", columnDefinition = "CHAR DEFAULT 'Y'", length = 1)
    @Convert(converter = BooleanToYnConverter.class)
    private boolean useYn;

	@CreatedDate
    @Column(name = "REG_DT", updatable = false)
    private LocalDateTime regDt;

	@LastModifiedDate
    @Column(name = "UPDT_DT")
    private LocalDateTime updtDt;
}
