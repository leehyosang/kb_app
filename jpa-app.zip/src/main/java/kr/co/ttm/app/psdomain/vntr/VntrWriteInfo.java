package kr.co.ttm.app.psdomain.vntr;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Entity
@Table(name="vntr_basic_info")
@EntityListeners(value = { AuditingEntityListener.class })
public class VntrWriteInfo {
	
	@Id
	@Column(name="CompanyRegistrationNumber", length = 12)
	private String companyRegistrationNumber;
	
	
	@Column(name="RnDRegisterApprovalNumber", length = 10)
	private String rnDRegisterApprovalNumber;

	@Column(name="CompanyName", length = 50)
	private String companyName;

	@Column(name="TotalAssets", length = 10)
	private long totalAssets;

	@Column(name="CapitalStock", length = 10)
	private long capitalStock;

	@Column(name="SalesAll", length = 10)
	private long salesAll;

	@Column(name="SalesBusinessCategory", length = 10)
	private long salesBusinessCategory;

	@Column(name="RegistrationField", length = 50)
	private String registrationField;

	@Column(name="CompanyType", length = 50)
	private String companyType;

	@Column(name="MajorActivity1", length = 30)
	private String majorActivity1;

	@Column(name="MajorActivity2", length = 30)
	private String majorActivity2;

	@Column(name="MajorActivity3", length = 30)
	private String majorActivity3;

	@Column(name="EmployeeCount", length = 10)
	private long employeeCount;

	@Column(name="EngineerCount", length = 10)
	private long engineerCount;

	@Column(name="FacilityCount", length = 10)
	private long facilityCount;

	@Column(name="ResearchSpaceType", length = 50)
	private String researchSpaceType;

	@Column(name="ResearchInvestmentResearchCost", length = 10)
	private long researchInvestmentResearchCost;

	@Column(name="ResearchInvestmentFacilityCost", length = 10)
	private long researchInvestmentFacilityCost;
}