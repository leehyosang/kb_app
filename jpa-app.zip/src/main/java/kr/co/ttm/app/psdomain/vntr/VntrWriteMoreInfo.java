package kr.co.ttm.app.psdomain.vntr;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Entity
@Table(name="vntr_more_info")
@EntityListeners(value = { AuditingEntityListener.class })
public class VntrWriteMoreInfo {
	
	@Id
	@Column(name="CompanyRegistrationNumber", length = 12)
	private String companyRegistrationNumber;
	
	@Column(name="RnDRegisterApprovalNumber", length = 10)
	private String rnDRegisterApprovalNumber;

	@Column(name="CompanyName", length = 100)
	private String companyName;

	@Column(name="FacilityGoodsName", length = 50)
	private String facilityGoodsName;
	
	@Column(name="FacilityModelName", length = 50)
	private String facilityModelName;
	
	@Column(name="FacilityUnitCost", length = 8)
	private long facilityUnitCost;
	
	@Column(name="FacilityQuantity", length = 10)
	private long facilityQuantity;

	@Column(name="FacilityProductionCompany", length = 50)
	private String facilityProductionCompany;

	@Column(name="FacilityInstallationPlace", length = 50)
	private String facilityInstallationPlace;

	@Column(name="FacilityIntroductionDate", length = 50)
	private String facilityIntroductionDate;

	@Column(name="FacilityUseCode", length = 50)
	private String facilityUseCode;
}