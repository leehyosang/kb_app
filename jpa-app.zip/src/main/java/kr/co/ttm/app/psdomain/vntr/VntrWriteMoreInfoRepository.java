package kr.co.ttm.app.psdomain.vntr;

import org.springframework.data.jpa.repository.JpaRepository;

public interface VntrWriteMoreInfoRepository extends JpaRepository<VntrWriteMoreInfo, Integer> {
	/*
	@Query("select r from RankInfo r "
			+ "where r.keyword = ?1 "
			+ "and r.serviceType = ?2 "
			+ "and r.regDt >= ?3"
			)
	public Page<RankInfo> findByKeywordAndServiceType(String keyword, ServiceType serviceType, LocalDateTime time, Pageable pageable);
	
	@Query(value = "select r.* from rank_info r "
			+ "where r.keyword = ?1 "
			+ "and r.srv_type = ?2 "
			+ "order by r.reg_dt desc "
			+ "limit 1 ", nativeQuery = true)
	public RankInfo findByKeywordAndServiceType(String keyword, String serviceType);
	*/
}
