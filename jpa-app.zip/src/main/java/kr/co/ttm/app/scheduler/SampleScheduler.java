package kr.co.ttm.app.scheduler;

import org.springframework.scheduling.Trigger;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Component;

import kr.co.ttm.app.core.scheduler.TTMDynamicScheduler;
import kr.co.ttm.app.core.scheduler.TTMSchedulerController;
import kr.co.ttm.app.psdomain.scheduler.SchedulerInfo;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Component
public class SampleScheduler extends TTMDynamicScheduler{	
	
	private TTMSchedulerController schdCont;
	
	
	/**
	 * 스케쥴러 그룹 및 이름 정의
	 * 해당 클래스 필드의 모든 필드멤버를 정의해야 함
	 * @param schdCont
	 */
	public SampleScheduler(TTMSchedulerController schdCont) {
		this.schdCont = schdCont;
		this.setSchdGrp("TEST");
		this.setSchdNm("SCHD1");
	}
	
	@Override
	public void runner() {
		// TODO Auto-generated method stub
		logger.info("sample job");
		
		// 실행시간 업데이트
		this.schdCont.updateLastRuntime(this.getSchdGrp(), this.getSchdNm());			
	}

	@Override
	public Trigger getTrigger() {			
		SchedulerInfo info = this.schdCont
				.getSchedulerInfo(this.getSchdGrp(), this.getSchdNm());
		
		
		return new CronTrigger(info.getCronExp());
	}

	

}
