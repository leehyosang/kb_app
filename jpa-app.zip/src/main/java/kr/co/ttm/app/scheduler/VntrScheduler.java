package kr.co.ttm.app.scheduler;

import org.springframework.scheduling.Trigger;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Component;

import kr.co.ttm.app.core.scheduler.TTMDynamicScheduler;
import kr.co.ttm.app.core.scheduler.TTMSchedulerController;
import kr.co.ttm.app.psdomain.scheduler.SchedulerInfo;
import kr.co.ttm.app.service.VntrService;

@Component
public class VntrScheduler extends TTMDynamicScheduler{	
	
	private TTMSchedulerController schdCont;
	
	private final VntrService vntrService;
	
	/**
	 * 스케쥴러 그룹 및 이름 정의
	 * 해당 클래스 필드의 모든 필드멤버를 정의해야 함
	 * @param schdCont
	 */
	public VntrScheduler(TTMSchedulerController schdCont, VntrService vntrService) {
		this.schdCont = schdCont;
		this.setSchdGrp("VNTR");
		this.setSchdNm("VNTR_BASIC");
		this.vntrService = vntrService;
	}
	
	@Override
	public void runner() {
		// TODO Auto-generated method stub
		logger.info("vntr job");

		// 실행시간 업데이트
		this.schdCont.updateLastRuntime(this.getSchdGrp(), this.getSchdNm());
		
		//수집기 실행
		try {
			System.out.println("연구개발협회 스케쥴러");
			//체크
			System.out.println("체크");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public Trigger getTrigger() {			
		SchedulerInfo info = this.schdCont
				.getSchedulerInfo(this.getSchdGrp(), this.getSchdNm());
		
		
		return new CronTrigger(info.getCronExp());
	}

	

}
