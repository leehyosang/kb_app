package kr.co.ttm.app.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import kr.co.ttm.app.core.TTMServiceCore;
import kr.co.ttm.app.mydomain.vntr.VntrInfo;
import kr.co.ttm.app.mydomain.vntr.VntrInfoRepository;
import kr.co.ttm.app.mydomain.vntr.VntrMoreInfo;
import kr.co.ttm.app.mydomain.vntr.VntrMoreInfoRepository;
import kr.co.ttm.app.mydomain.vntr.VntrSellInfo;
import kr.co.ttm.app.mydomain.vntr.VntrSellInfoRepository;
import kr.co.ttm.app.psdomain.vntr.VntrWriteInfo;
import kr.co.ttm.app.psdomain.vntr.VntrWriteInfoDaily;
import kr.co.ttm.app.psdomain.vntr.VntrWriteInfoDailyRepository;
import kr.co.ttm.app.psdomain.vntr.VntrWriteInfoRepository;
import kr.co.ttm.app.psdomain.vntr.VntrWriteMoreInfo;
import kr.co.ttm.app.psdomain.vntr.VntrWriteMoreInfoDaily;
import kr.co.ttm.app.psdomain.vntr.VntrWriteMoreInfoDailyRepository;
import kr.co.ttm.app.psdomain.vntr.VntrWriteMoreInfoRepository;
import kr.co.ttm.app.psdomain.vntr.VntrWriteSellInfo;
import kr.co.ttm.app.psdomain.vntr.VntrWriteSellInfoDaily;
import kr.co.ttm.app.psdomain.vntr.VntrWriteSellInfoDailyRepository;
import kr.co.ttm.app.psdomain.vntr.VntrWriteSellInfoRepository;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
@Component
public class VntrService extends TTMServiceCore{

	//mssql_repo(read)
	private VntrInfoRepository vntroReadRepo;
	private VntrMoreInfoRepository vntroMoreReadRepo;
	private VntrSellInfoRepository vntroSellReadRepo;
	
	//postgre_repo(write)
	private VntrWriteInfoRepository vntroWriteRepo;
	private VntrWriteInfoDailyRepository vntroWriteDailyRepo;
	
	private VntrWriteMoreInfoRepository vntroWriteMoreRepo;
	private VntrWriteMoreInfoDailyRepository vntroWriteMoreDailyRepo;
	
	private VntrWriteSellInfoRepository vntroWriteSellRepo;
	private VntrWriteSellInfoDailyRepository vntroWriteSellDailyRepo;
	
	//basic data
	public void getCollectData() throws Exception {
		List<VntrInfo> list = vntroReadRepo.getVntrList();
		this.runVntrInfoData(list);
	}
	
	//more data
	public void getCollectMoreData() throws Exception {
		List<VntrMoreInfo> list = vntroMoreReadRepo.getVntrMoreList();
		this.runVntrMoreInfoData(list);
	}
	
	//sell data
	public void getCollectSellData() throws Exception {
		List<VntrSellInfo> list = vntroSellReadRepo.getVntrSellList();
		this.runVntrSellInfoData(list);
	}
@SuppressWarnings("unchecked")
public void runVntrInfoData(List<VntrInfo> list) {
		
		try {
			
			//년월일
			LocalDate now = LocalDate.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
			String formatedNow = now.format(formatter);
			
			if(list.size() > 0) {
	        		for(int i=0; i<list.size(); i++) {
	        			System.out.println("vntr_basic_info"+list.get(i).toString());
	        			String rnDRegisterApprovalNumber = list.get(i).getRnDRegisterApprovalNumber() == null ? "" : list.get(i).getRnDRegisterApprovalNumber().toString();
	        			String companyName = list.get(i).getCompanyName() == null ? "" : list.get(i).getCompanyName().toString();
	        			String companyRegistrationNumber = list.get(i).getCompanyRegistrationNumber() == null ? "" : list.get(i).getCompanyRegistrationNumber().toString();
	        			int totalAssets = list.get(i).getTotalAssets() == null ? 0 : list.get(i).getTotalAssets();
	        			int capitalStock = list.get(i).getCapitalStock() == null ? 0 : list.get(i).getCapitalStock();
	        			int salesAll = list.get(i).getSalesAll() == null ? 0 : list.get(i).getSalesAll();
	        			int salesBusinessCategory = list.get(i).getSalesBusinessCategory() == null ? 0 : list.get(i).getSalesBusinessCategory();
	        			String registrationField = list.get(i).getRegistrationField() == null ? "" : list.get(i).getRegistrationField().toString();
	        			String majorActivity1 = list.get(i).getMajorActivity1() == null ? "" : list.get(i).getMajorActivity1().toString();
	        			String majorActivity2 = list.get(i).getMajorActivity2() == null ? "" : list.get(i).getMajorActivity2().toString();
	        			String majorActivity3 = list.get(i).getMajorActivity3() == null ? "" : list.get(i).getMajorActivity3().toString();
	        			int employeeCount = list.get(i).getEmployeeCount() == null ? 0 : list.get(i).getEmployeeCount();
	        			int engineerCount = list.get(i).getEngineerCount() == null ? 0 : list.get(i).getEngineerCount();
	        			int facilityCount = list.get(i).getFacilityCount() == null ? 0 : list.get(i).getFacilityCount();
	        			String researchSpaceType = list.get(i).getResearchSpaceType() == null ? "" : list.get(i).getResearchSpaceType().toString();
	        			int researchInvestmentResearchCost = list.get(i).getResearchInvestmentResearchCost() == null ? 0 : list.get(i).getResearchInvestmentResearchCost();
	        			int researchInvestmentFacilityCost = list.get(i).getResearchInvestmentFacilityCost() == null ? 0 : list.get(i).getResearchInvestmentFacilityCost();
	        			
	        			
	        			//vntr_basic 데이터 등록
	        			VntrWriteInfo vntrWriteInfo = VntrWriteInfo.builder()
	        					.rnDRegisterApprovalNumber(rnDRegisterApprovalNumber)
	        					.companyName(companyName)
	        					.companyRegistrationNumber(companyRegistrationNumber)
	        					.totalAssets(totalAssets)
	        					.capitalStock(capitalStock)
	        					.salesAll(salesAll)
	        					.salesBusinessCategory(salesBusinessCategory)
	        					.registrationField(registrationField)
	        					.companyType(list.get(i).getCompanyType() == null ? "" : list.get(i).getCompanyType())
	        					.majorActivity1(majorActivity1)
	        					.majorActivity2(majorActivity2)
	        					.majorActivity3(majorActivity3)
	        					.employeeCount(employeeCount)
	        					.engineerCount(engineerCount)
	        					.facilityCount(facilityCount)
	        					.researchSpaceType(researchSpaceType)
	        					.researchInvestmentResearchCost(researchInvestmentResearchCost)
	        					.researchInvestmentFacilityCost(researchInvestmentFacilityCost)
	        					.build();
	        			vntroWriteRepo.save(vntrWriteInfo);
	        			
	        			//vntr_basic_daily 데이터 등록
	        			VntrWriteInfoDaily vntrWriteInfoDaily = VntrWriteInfoDaily.builder()
	        					.insertDate(formatedNow)
	        					.rnDRegisterApprovalNumber(rnDRegisterApprovalNumber)
	        					.companyName(companyName)
	        					.companyRegistrationNumber(companyRegistrationNumber)
	        					.totalAssets(totalAssets)
	        					.capitalStock(capitalStock)
	        					.salesAll(salesAll)
	        					.salesBusinessCategory(salesBusinessCategory)
	        					.registrationField(registrationField)
	        					.companyType(list.get(i).getCompanyType() == null ? "" : list.get(i).getCompanyType())
	        					.majorActivity1(majorActivity1)
	        					.majorActivity2(majorActivity2)
	        					.majorActivity3(majorActivity3)
	        					.employeeCount(employeeCount)
	        					.engineerCount(engineerCount)
	        					.facilityCount(facilityCount)
	        					.researchSpaceType(researchSpaceType)
	        					.researchInvestmentResearchCost(researchInvestmentResearchCost)
	        					.researchInvestmentFacilityCost(researchInvestmentFacilityCost)
	        					.build();
	        			vntroWriteDailyRepo.save(vntrWriteInfoDaily);
	        		}
	        		
	        }else {
	        	System.out.println("no vntr_basic_data"); 
	        }
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

@SuppressWarnings("unchecked")
public void runVntrMoreInfoData(List<VntrMoreInfo> list) {
		
		try {
			
			//년월일
			LocalDate now = LocalDate.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
			String formatedNow = now.format(formatter);
			
			if(list.size() > 0) {
	        		for(int i=0; i<list.size(); i++) {
	        			System.out.println("vntr_more_info"+list.get(i).toString());
	        			String rnDRegisterApprovalNumber = list.get(i).getRnDRegisterApprovalNumber() == null ? "" : list.get(i).getRnDRegisterApprovalNumber().toString();
	        			String companyName = list.get(i).getCompanyName() == null ? "" : list.get(i).getCompanyName().toString();
	        			String companyRegistrationNumber = list.get(i).getCompanyRegistrationNumber() == null ? "" : list.get(i).getCompanyRegistrationNumber().toString();
	        			String facilityGoodsName = list.get(i).getFacilityGoodsName() == null ? "" : list.get(i).getFacilityGoodsName().toString();
	        			String facilityModelName = list.get(i).getFacilityModelName() == null ? "" : list.get(i).getFacilityModelName().toString();
	        			int facilityUnitCost = list.get(i).getFacilityUnitCost() == null ? 0 : list.get(i).getFacilityUnitCost();
	        			int facilityQuantity = list.get(i).getFacilityQuantity() == null ? 0 : list.get(i).getFacilityQuantity();
	        			String facilityProductionCompany = list.get(i).getFacilityProductionCompany() == null ? "" : list.get(i).getFacilityProductionCompany().toString();
	        			String facilityInstallationPlace = list.get(i).getFacilityInstallationPlace() == null ? "" : list.get(i).getFacilityInstallationPlace().toString();
	        			String facilityIntroductionDate = list.get(i).getFacilityIntroductionDate() == null ? "" : list.get(i).getFacilityIntroductionDate().toString();
	        			String facilityUseCode = list.get(i).getFacilityUseCode() == null ? "" : list.get(i).getFacilityUseCode().toString();
	        			
	        			//vntr_more 데이터 등록
	        			VntrWriteMoreInfo vntrWriteMoreInfo = VntrWriteMoreInfo.builder()
	        					.rnDRegisterApprovalNumber(rnDRegisterApprovalNumber)
	        					.companyName(companyName)
	        					.companyRegistrationNumber(companyRegistrationNumber)
	        					.facilityGoodsName(facilityGoodsName)
	        					.facilityModelName(facilityModelName)
	        					.facilityUnitCost(facilityUnitCost)
	        					.facilityQuantity(facilityQuantity)
	        					.facilityProductionCompany(facilityProductionCompany)
	        					.facilityInstallationPlace(facilityInstallationPlace)
	        					.facilityIntroductionDate(facilityIntroductionDate)
	        					.facilityUseCode(facilityUseCode)
	        					.build();
	        			vntroWriteMoreRepo.save(vntrWriteMoreInfo);
	        			
	        			//vntr_more_daily 데이터 등록
	        			VntrWriteMoreInfoDaily vntrWriteMoreInfoDaily = VntrWriteMoreInfoDaily.builder()
	        					.insertDate(formatedNow)
	        					.rnDRegisterApprovalNumber(rnDRegisterApprovalNumber)
	        					.companyName(companyName)
	        					.companyRegistrationNumber(companyRegistrationNumber)
	        					.facilityGoodsName(facilityGoodsName)
	        					.facilityModelName(facilityModelName)
	        					.facilityUnitCost(facilityUnitCost)
	        					.facilityQuantity(facilityQuantity)
	        					.facilityProductionCompany(facilityProductionCompany)
	        					.facilityInstallationPlace(facilityInstallationPlace)
	        					.facilityIntroductionDate(facilityIntroductionDate)
	        					.facilityUseCode(facilityUseCode)
	        					.build();
	        			vntroWriteMoreDailyRepo.save(vntrWriteMoreInfoDaily);
	        		}
	        		
	        }else {
	        	System.out.println("no vntr_more_data"); 
	        }
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

@SuppressWarnings("unchecked")
public void runVntrSellInfoData(List<VntrSellInfo> list) {
		
		try {
			
			//년월일
			LocalDate now = LocalDate.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
			String formatedNow = now.format(formatter);
			
			if(list.size() > 0) {
	        		for(int i=0; i<list.size(); i++) {
	        			System.out.println("vntr_sell_info"+list.get(i).toString());
	        			String rnDRegisterApprovalNumber = list.get(i).getRnDRegisterApprovalNumber() == null ? "" : list.get(i).getRnDRegisterApprovalNumber().toString();
	        			String companyName = list.get(i).getCompanyName() == null ? "" : list.get(i).getCompanyName().toString();
	        			String companyRegistrationNumber = list.get(i).getCompanyRegistrationNumber() == null ? "" : list.get(i).getCompanyRegistrationNumber().toString();
	        			String chargeName = list.get(i).getChargeName() == null ? "" : list.get(i).getChargeName().toString();
	        			String chargePosition = list.get(i).getChargePosition() == null ? "" : list.get(i).getChargePosition().toString();
	        			String chargePhoneNumber = list.get(i).getChargePhoneNumber() == null ? "" : list.get(i).getChargePhoneNumber().toString();
	        			String homepage = list.get(i).getHomepage() == null ? "" : list.get(i).getHomepage().toString();
	        			String businessCategoryClassification = list.get(i).getBusinessCategoryClassification() == null ? "" : list.get(i).getBusinessCategoryClassification().toString();
	        			String foundationDate = list.get(i).getFoundationDate() == null ? "" : list.get(i).getFoundationDate().toString();
	        			String ceoName = list.get(i).getCEOName() == null ? "" : list.get(i).getCEOName().toString();
	        			String address = list.get(i).getAddress() == null ? "" : list.get(i).getAddress().toString();
	        			String telNumber = list.get(i).getTelNumber() == null ? "" : list.get(i).getTelNumber().toString();
	        			String faxNumber = list.get(i).getFaxNumber() == null ? "" : list.get(i).getFaxNumber().toString();
	        			
	        			
	        			//vntr_sell 데이터 등록
	        			VntrWriteSellInfo vntrWriteSellInfo = VntrWriteSellInfo.builder()
	        					.rnDRegisterApprovalNumber(rnDRegisterApprovalNumber)
	        					.companyName(companyName)
	        					.companyRegistrationNumber(companyRegistrationNumber)
	        					.chargeName(chargeName)
	        					.chargePosition(chargePosition)
	        					.chargePhoneNumber(chargePhoneNumber)
	        					.homepage(homepage)
	        					.businessCategoryClassification(businessCategoryClassification)
	        					.foundationDate(foundationDate)
	        					.cEOName(ceoName)
	        					.address(address)
	        					.telNumber(telNumber)
	        					.faxNumber(faxNumber)
	        					.build();
	        			vntroWriteSellRepo.save(vntrWriteSellInfo);
	        			
	        			//vntr_sell_daily 데이터 등록
	        			VntrWriteSellInfoDaily vntrWriteSellInfoDaily = VntrWriteSellInfoDaily.builder()
	        					.insertDate(formatedNow)
	        					.rnDRegisterApprovalNumber(rnDRegisterApprovalNumber)
	        					.companyName(companyName)
	        					.companyRegistrationNumber(companyRegistrationNumber)
	        					.chargeName(chargeName)
	        					.chargePosition(chargePosition)
	        					.chargePhoneNumber(chargePhoneNumber)
	        					.homepage(homepage)
	        					.businessCategoryClassification(businessCategoryClassification)
	        					.foundationDate(foundationDate)
	        					.cEOName(ceoName)
	        					.address(address)
	        					.telNumber(telNumber)
	        					.faxNumber(faxNumber)
	        					.build();
	        			vntroWriteSellDailyRepo.save(vntrWriteSellInfoDaily);
	        		}
	        		
	        }else {
	        	System.out.println("no vntr_sell_data"); 
	        }
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
