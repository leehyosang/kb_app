package kr.co.ttm.app.utils.crypt.aes;

import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.tomcat.util.codec.binary.Base64;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.security.crypto.codec.Hex;

//TODO 수정필요
public class AES {
	/*
	private static final String passphrase = "@TTM_CRYPT_2019_05_17_$";	
	
	static public String decryptBase64(String base64Str) throws Exception{	
		JSONParser parser = new JSONParser();
		JSONObject json = (JSONObject) parser.parse(new String(Base64.decodeBase64(base64Str)));
		
	    return doDecrypt(json.get("salt").toString(), json.get("iv").toString(), 
	    		AES.passphrase, json.get("data").toString(), 10000, 128);	    
	}
	
	static public String decrypt(String ciphertext, String iv, String salt) throws Exception{
	    return doDecrypt(salt, iv, AES.passphrase, ciphertext, 10000, 128);	    
	}
	
	
	private static String doDecrypt(String salt, String iv, String passphrase, String ciphertext, int iterationCount, int keySize) throws Exception {        
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
        KeySpec spec = new PBEKeySpec(passphrase.toCharArray(),  Hex.decodeHex(salt.toCharArray()), iterationCount, keySize);
        SecretKey key = new SecretKeySpec(factory.generateSecret(spec).getEncoded(), "AES");        
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(Hex.decodeHex(iv.toCharArray())));        
        byte[] decrypted = cipher.doFinal(Base64.decodeBase64(ciphertext));        
        return new String(decrypted, "UTF-8");
    }
	*/

}
