package kr.co.ttm.app.utils.crypt.aria;

import kr.co.ttm.app.utils.crypt.aria.core.Aria;
import kr.co.ttm.app.utils.crypt.aria.core.AriaConstants;

public class AriaCrypt {
    private static String key = "";
    static String key1 = AriaConstants.KEY_01;
    static String key2 = AriaConstants.KEY_02;
    static String key3 = AriaConstants.KEY_03;
    static String key4 = AriaConstants.KEY_04;
    
    static String part = "";
    
    private String setKey(String part){
        if(part=="LSE"){
            key = key1;
        }
        else if(part.equals("A1")){
            key = key2;
        }else if(part.equals("A2")){
            key = key3;
        }else{
            key = key4;
        };
        return key;
    }
    /**
     * <pre>
     * 메소드 한글명 : Aria 암호화
     * 설명 :  ARIA 암복호화
     * </pre>
     *
     * @param string
     * @return
     * @throws Warning
     */
    public String Encrypt(String input,String part){
        Aria aria = new Aria(setKey(part));
        String encData = aria.Encrypt(input);
        return encData;
    }
    public String Encrypt(String input){
        Aria aria = new Aria(setKey("A1"));
        String encData = aria.Encrypt(input);
        return encData;
    }
    /**
     * <pre>
     * 메소드 한글명 : Aria 복호화
     * 설명 :  ARIA 암복호화
     * </pre>
     *
     * @param string
     * @return
     * @throws Warning
     */
    public String Decrypt(String endData,String part){
        Aria aria = new Aria(setKey(part));
        String data = aria.Decrypt(endData);
        return data;
    }
    public String Decrypt(String endData){
        Aria aria = new Aria(setKey("A1"));
        String data = aria.Decrypt(endData);
        return data;
    }

}
