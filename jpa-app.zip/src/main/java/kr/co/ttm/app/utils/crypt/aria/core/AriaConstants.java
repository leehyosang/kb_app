package kr.co.ttm.app.utils.crypt.aria.core;

public class AriaConstants {

    public static final String KEY_01 = "791DBD17442FE2DB939640EC233CDC7A";
    
    public static final String KEY_02 = "96EE0FBF4DD53D02C372C0F1C5082835";
    
    public static final String KEY_03 = "2F0EDEF9D9AB48E2DF9BD7637A6156CB";
    
    public static final String KEY_04 = "5C92F01B0D6858D7AE3B0F77A0354C4D";
    
}
