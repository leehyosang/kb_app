package kr.co.ttm.app.vo;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AjaxResult {
	static public final int SUCCESS = 200;
	static public final int FAIL = 500;
	
	private int status;
	private String message;
	private Object data;
	private String time;
	
}
