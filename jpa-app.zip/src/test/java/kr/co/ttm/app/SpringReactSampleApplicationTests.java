package kr.co.ttm.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringReactSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
