package com.ttmsoft.lms.cmm.config;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
public class PostgreSqlConfig {
	
	@Autowired
	ApplicationContext applicationContext;
	
	@Primary
    @Bean(name = "postgresqlDataSource")
    @ConfigurationProperties(prefix = "spring.datasource.postgresql")
    public DataSource firstDataSource() {
        return DataSourceBuilder.create().build();
    }

	@Primary
    @Bean(name="postgresqlSession")
	public SqlSessionFactory sqlSessionFactory(@Qualifier("postgresqlDataSource") DataSource dataSource) throws Exception {
		
		SqlSessionFactoryBean sqlSessionFactory = new SqlSessionFactoryBean();
		sqlSessionFactory.setDataSource(dataSource);
		//sqlSessionFactory.setTypeAliasesPackage("ttmsoft.lms.basemvc");
		sqlSessionFactory.setConfigLocation(applicationContext.getResource("classpath:config/mybatis-config.xml"));
		sqlSessionFactory.setMapperLocations(new PathMatchingResourcePatternResolver().getResources("classpath:sqlmap/postgres/**/*SQL.xml"));
		
		return sqlSessionFactory.getObject();
	}
	
	@Primary
    @Bean(name = "postgresqlTransactionManager")
	public PlatformTransactionManager transactionManager(@Qualifier("postgresqlDataSource")  DataSource dataSource) {
		return new DataSourceTransactionManager(dataSource);
	}

}
