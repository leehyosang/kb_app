package com.ttmsoft.toaf.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Address;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.Part;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.mail.MailException;
import org.springframework.stereotype.Component;

import com.ttmsoft.toaf.object.DataMap;

@Component
public class CommonUtil {
	
	/**
	 * 문자열을 Byte 수 만큼 자르고 "..." 을 붙여 잘린 문자열임을 표시
	 *
	 * @param src
	 * @param max
	 * @return
	 */
	public static String cutByteString (String src, int max) {
		String result = "";

		if ((null == src) || "".equals(src)) return result;
		if (max <= 0) return src;

		try {
			char curChar;
			byte[] curBytes;
			int nowsz = 0, strsz = 0;
			for (int i = 0; i < src.length(); i++) {
				curChar = src.charAt(i);

				curBytes = ("" + curChar).getBytes("UTF-8");
				strsz = curBytes.length;

				if (strsz == 3) nowsz += 2;
				else nowsz += strsz;

				if (nowsz > max) break;
				else result += curChar;
			}
			if (src.length() > result.length()) result += "...";
		}
		catch (Exception e) {
			result = src;
		}

		return result;
	}

	/**
	 * 리스트에 담긴 컬럼(단수)의 길이를 btye 단위로 잘라준다.
	 * 
	 * @param list
	 * @param columName
	 * @param length
	 */
	public static void cutTitle (List<DataMap> list, String columName, int length) {
		for (DataMap dataMap : list) {
			dataMap.put(columName, cutByteString(String.valueOf(dataMap.get(columName)), length));
		}
	}

	/**
	 * 다국어 지원 ResourceBundle 객체 생성
	 * 
	 * @param baseName
	 * @param request
	 * @return
	 */
	public static ResourceBundle getResourceBundle (String baseName, HttpServletRequest request) {
		ResourceBundle result = null;

		String tmpStr = request.getHeader("Accept-Language");
		String lang = "en";
		try {
			if (tmpStr != null && tmpStr.length() > 1) {
				lang = tmpStr.substring(0, 2).toLowerCase();
			}	
			java.util.Locale locale = new java.util.Locale(lang, "");
			result = ResourceBundle.getBundle(baseName, locale);
		}
		catch (Exception e) {
			result = ResourceBundle.getBundle(baseName, java.util.Locale.ENGLISH);
		}

		return result;
	}

	/**
	 * 세션 language 얻기 - Locale("ko")
	 * 
	 * @param request
	 * @return
	 */
	public static Locale getLocale (HttpServletRequest request) {
		return new Locale(String.valueOf(request.getSession().getAttribute("sess_lang")));
	}

	/**
	 * 클라이언트 IP 얻기
	 * 
	 * @param req
	 * @return
	 */
	public static String getRemoteAddress (HttpServletRequest req) {
		String ip = req.getHeader("X-FORWARDED-FOR");
		if (ip == null || ip.length() == 0) ip = req.getHeader("Proxy-Client-IP");
		if (ip == null || ip.length() == 0) ip = req.getRemoteAddr();

		return ip;
	}

	
	/**
	 * 엑셀 다운로드
	 * @return 
	 * @throws JSONException 
	 */
	public SXSSFWorkbook doExcelDown(DataMap dataMap, HttpServletResponse response) throws JSONException{
		
		@SuppressWarnings("resource")
		SXSSFWorkbook workbook = new SXSSFWorkbook();
		try {
		String key = dataMap.getstr("key");
		List<DataMap> list = (List<DataMap>) dataMap.get("list");
		String titleListStr[] = key.split(",");
        String keyListStr[] = key.split(",");
        
        JSONArray chartJsonList = ExcelUtil.toJsonArray(key,list);
        
        List<DataMap> chartList = new ArrayList<DataMap>();
        List<String> titleList = new ArrayList<String>();
        List<String> keyList = new ArrayList<String>();
        
        for(int i = 0; i < titleListStr.length; i++) {
            titleList.add(titleListStr[i]);
         }
         for(int i = 0; i < keyListStr.length; i++) {
            keyList.add(keyListStr[i]);
         }
         
         for(int i=0; i < chartJsonList.length(); i++) {
            JSONObject object = chartJsonList.getJSONObject(i);
            DataMap temp = new DataMap();
            for(int j = 0; j < keyListStr.length; j++) {
               temp.put(keyListStr[j], object.getString(keyListStr[j]));
            } 
            
            chartList.add(temp);
         }
         
         dataMap.put("excel_title", titleList);
         dataMap.put("excel_data", chartList);
         dataMap.put("data_key", keyList);
         
         workbook = ExcelUtil.ExcelDown(response, dataMap);
         
		}catch (MailException e) {
			e.printStackTrace();
		}
		return workbook;
	}
	
	// 이미지를 로컬로 부터 읽어와서 BodyPart 클래스로 만든다. (바운더리 변환)
	   private BodyPart getImage(String filename, String contextId) throws MessagingException {
	      //파일을 읽어와서 BodyPart 클래스로 받는다.
	      BodyPart mbp = getFileAttachment(filename);
	      if (contextId != null) {
	         // ContextId 설정
	         mbp.setHeader("Content-ID", "<" + contextId + ">");
	      }
	      return mbp;
	   }
	   // 파일을 로컬로 부터 읽어와서 BodyPart 클래스로 만든다. (바운더리 변환)
	   private BodyPart getFileAttachment(String filename) throws MessagingException {
	      // BodyPart 생성
	      BodyPart mbp = new MimeBodyPart();
	      
	      // 파일 읽어서 BodyPart에 설정(바운더리 변환)
	      File file = new File(filename);
	      
	      DataSource source = new FileDataSource(file);
	      mbp.setDataHandler(new DataHandler(source));
	      mbp.setDisposition(Part.ATTACHMENT);
	      mbp.setFileName(file.getName());
	      
	      return mbp;
	   }
	   // 메일의 본문 내용 설정
	   private BodyPart getContents(String html) throws MessagingException {
	      BodyPart mbp = new MimeBodyPart();
	      //setText를 이용할 경우 일반 텍스트 내용으로 설정된다.
	      //mbp.setText(html);
	      //html 형식으로 설정
	      mbp.setContent(html, "text/html; charset=utf-8");
	      return mbp;
	   }
	   
	   //String으로 된 메일 주소를 Address 클래스로 변환
	   private Address getAddress(String address) throws AddressException {
	      return new InternetAddress(address);
	   }
	   
	   //String으로 된 복수의 메일 주소를 콤마(,)의 구분으로 Address array형태로 변환
	   private Address[] getAddresses(String addresses) throws AddressException {
	      String[] array = addresses.split(",");
	      Address[] ret = new Address[array.length];
	      for (int i = 0; i < ret.length; i++) {
	         ret[i] = getAddress(array[i]);
	      }
	      return ret;
	   }
	   
	   /**
	    * 바이너리 스트링을 파일로 변환
	    *
	    * @param binaryFile
	    * @param filePath
	    * @param fileName 
	    * @return
	    */
	   public static File binaryToFile(String binaryFile, String filePath, String fileName) {
	       if ((binaryFile == null || "".equals(binaryFile)) || (filePath == null || "".equals(filePath))
	               || (fileName == null || "".equals(fileName))) { return null; }
	    
	       FileOutputStream fos = null;
	    
	       File fileDir = new File(filePath);
	       if (!fileDir.exists()) {
	           fileDir.mkdirs();
	       }
	    
	       File destFile = new File(filePath + fileName);
	    
	       byte[] buff = binaryFile.getBytes();
	       String toStr = new String(buff);
	       byte[] b64dec = base64Dec(toStr);
	    
	       try {
	           fos = new FileOutputStream(destFile);
	           fos.write(b64dec);
	           fos.close();
	       } catch (IOException e) {
	           System.out.println("Exception position : FileUtil - binaryToFile(String binaryFile, String filePath, String fileName)");
	       }
	    
	       return destFile;
	   }
	   
	   public static byte[] base64Dec(String toStr) {
		    return Base64.decodeBase64(toStr);
		}




}
