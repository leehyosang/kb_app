package com.ttmsoft.toaf.util;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;

import com.ttmsoft.toaf.object.DataMap;

public class ExcelUtil {
	public static SXSSFWorkbook ExcelDown(HttpServletResponse response, DataMap dataMap) {   
	      
	      SXSSFWorkbook workbook = new SXSSFWorkbook();
	      
	      try {
	         
	         //데이터 셋팅
	         List<String> titleList = (List<String>) dataMap.get("excel_title");
	         List<DataMap> dataList = (List<DataMap>) dataMap.get("excel_data");
	         List<DataMap> keyList = (List<DataMap>) dataMap.get("data_key");
	              
	           // 시트 생성
	           SXSSFSheet sheet = workbook.createSheet(dataMap.get("excel_sheet").toString());
	           
	           //시트 열 너비 설정
	           
	           sheet.setColumnWidth(0, 7*256);
	           sheet.setColumnWidth(1, 40*256);
	           sheet.setColumnWidth(2, 15*256);
	           sheet.setColumnWidth(3, 18*256);
	           sheet.setColumnWidth(4, 18*256);
	           sheet.setColumnWidth(5, 10*256);
	           sheet.setColumnWidth(6, 10*256);
	           sheet.setColumnWidth(7, 10*256);
	           sheet.setColumnWidth(8, 10*256);
	           sheet.setColumnWidth(9, 10*256);
	           
	           
	           // 헤더 행 생
	           Row headerRow = sheet.createRow(0);
	           
	           for(int i = 0; i < titleList.size(); i++) {
	              Cell headerCell = headerRow.createCell(i);
	              headerCell.setCellValue(titleList.get(i));
	           }
	           
	           // 내용 행 및 셀 생성
	           Row bodyRow = null;
	           Cell bodyCell = null;
	           for(int i = 0; i < dataList.size(); i++) {
	               // 행 생성
	               bodyRow = sheet.createRow(i+1);
	               // 데이터 번호 표시
	               for(int j = 0; j < keyList.size(); j++) {
	                  // 데이터 표시
	                  bodyCell = bodyRow.createCell(j);
	                  bodyCell.setCellValue(dataList.get(i).get(keyList.get(j)).toString());
	               }
	           }
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	        return workbook;
	   }
	//sql 결과값 jsonarray로 변경
	public static JSONArray toJsonArray(String key,List<DataMap> list) {
		JSONArray ary = new JSONArray();
		String[] listKey = key.split(",");
		
		for(int i=0; i<list.size();i++) {
			JSONObject obj = new JSONObject();
			for(int j=0; j<listKey.length;j++) {
				try {
					obj.put(listKey[j], list.get(i).getstr(listKey[j]));
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			ary.put(obj);
		}

		
		return ary;
	}
}
