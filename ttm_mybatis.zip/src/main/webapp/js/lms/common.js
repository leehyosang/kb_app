
function initDatePicker(tag){

	tag.forEach(function(dataPicker){
		$(dataPicker).datepicker({
			showOn: "button",
			buttonImage: "../images/admin/ico/icon_calendar1.png",
			buttonImageOnly: true, // 버튼에 있는 이미지만 표시한다.
			nextText: '다음 달', // next 아이콘의 툴팁.
			prevText: '이전 달', // prev 아이콘의 툴팁.
			stepMonths: 1, // next, prev 버튼을 클릭했을때 얼마나 많은 월을 이동하여 표시하는가. 
			dateFormat: "yy-mm-dd", // 텍스트 필드에 입력되는 날짜 형식.
			showAnim: "slide", //애니메이션을 적용한다.
			showMonthAfterYear: true, // 월, 년순의 셀렉트 박스를 년,월 순으로 바꿔준다. 
			dayNamesMin: ['일','월', '화', '수', '목', '금', '토'], // 요일의 한글 형식.
			monthNamesShort: ['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'] // 월의 한글 형식.
		});
	});		
}

function openDialog(options){
	
	console.log('title:' + options.title, ' width:' + options.width, ' height:' + options.height, + 'resizable' + options.resizable, ' url:' + options.url);
	
    $("#dialog").dialog({

    	title:options.title,
        autoOpen:false, //자동으로 열리지않게
        position:{my:"center"}, //x,y  값을 지정
        //"center", "left", "right", "top", "bottom"
        modal:true, //모달대화상자
        resizable:false, //크기 조절 못하게
        width:options.width,
        height:options.height,
        
        open: function() { 
        	$('#popContent').width($(this).width()-10); 
			$('#popContent').height($(this).height()-10); 
			
			if(options.closebtn == 'remove'){
				$(this).dialog().parents(".ui-dialog").find(".ui-dialog-titlebar-close").remove();
			}
		},
		close: function(){
			$('#popContent').attr('src','');
			$('#dialog').dialog('destroy');
		} 
    });
    
    $('#popContent').attr({src: options.url}).show();
    $("#dialog").dialog("open");
}

function validateInputVal(option, tag){
	
	var inputVal = $(tag).val();
	var regex = '';
	
	if(option == 'ko_num'){
		regex = /[^가-힣0-9]/gi;
	}else if(option == 'ko_num_blank'){
		regex = /[^가-힣0-9 ]/gi;
	}else if(option == 'en_num'){
		regex = /[^a-z0-9]/gi;
	}else if(option == 'en_num_blank'){
		regex = /[^a-z0-9 ]/gi;
	}else if(option == 'ko_en_num'){
		regex = /[^가-힣a-z0-9]/gi;
	}else if(option == 'ko_en_num_blank'){
		regex = /[^가-힣a-z0-9 ]/gi;
	}else if(option == 'ko'){
		regex = /[^가-힣]/gi;
	}else if(option == 'en'){
		regex = /[^a-z]/gi;
	}else if(option == 'num'){
		regex = /[^0-9]/gi;
	}else if(option == 'en_num_bar'){
		regex = /[^0-9a-zA-Z\-_]/gi;
	}
	
	$(tag).val(inputVal.replace(regex,''));
}

function isBlank(varName, inputTag){
	
	var inputVal = $(inputTag).val();
	
	if(inputVal == ''){
		alert(varName + '을(를) 입력해주세요.');
		$(inputTag).focus();
		return true;
	}
	return false;
}

function checkUseAuth(useAuth, insertBtnTages, updateBtnTages, deleteBtnTages){
	
	if(useAuth != null){
		
		if(useAuth.insert_yn == 'Y' && insertBtnTages != null){
			insertBtnTages.forEach(function(btn){
				btn.show();
			});					
		}
		
		if(useAuth.update_yn == 'Y' && updateBtnTages != null){
			updateBtnTages.forEach(function(btn){
				btn.show();
			});				
		}
		
		if(useAuth.delete_yn == 'Y' && deleteBtnTages != null){
			deleteBtnTages.forEach(function(btn){
				btn.show();
			});			
		}
	}
}
//연결 리스트
function linkedListNode(value) {
    this.value = value;
    this.next = null;
}

function LinkedList() {
	
	this.head = null;
    this.length = 0;
    
    this.append = function(value) {
        var node = new linkedListNode(value);
        var current = this.head;
        if (!current) { // 리스트가 비어있음
            this.head = node;
            this.length++;
            return node;
        } else {
            while (current.next) { //리스트의 끝을 찾아서
                current = current.next;
            }
            current.next = node; //끝에 추가
            this.length++;
            return node;
        }
    }
    
    this.find = function(position) {
    	var current = this.head;
    	var count = 0;
        while (count < position) {
            current = current.next;
            count++;
        }
        return current? current.value : null;
    }
    
    this.remove = function(position) {
    	var current = this.head;
    	var before;
        var remove;
        var count = 0;
        if (position == 0) { //제일 앞 삭제
            remove = this.head;
            this.head = this.head.next;
            this.length--;
            return remove;
        } else {
            while (count < position) {
                before = current;
                count++;
                current = current.next;
            }
            remove = current;
            before.next = remove? remove.next : null;
            this.length--;
            return remove;
        }
    }
}